<?php $__env->startSection('title','prodi'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Program Studi</h4>
                  <p class="card-description">
                    List data Program studi
                  </p>
                  <a href="<?php echo e(route('prodi.create')); ?>" class="btn btn-primary">tambah</a>
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Nama Program Studi</th>
                          <th>Singkatan</th>
                          <th>Nama Fakultas</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item["nama"]); ?></td>
                            <td><?php echo e($item["singkatan"]); ?></td>
                            <td><?php echo e($item["fakultas"]["nama"]); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Nicko(sementara)\laravelsi4b\laravelsi4b\example-app\resources\views/prodi/index.blade.php ENDPATH**/ ?>