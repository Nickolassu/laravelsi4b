

<?php $__env->startSection('title','Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Mahasiswa</h4>
                  <p class="card-description">
                    List data Mahasiswa 
                  </p>
                  <a href="<?php echo e(route('mahasiswa.create')); ?>" class="btn btn-primary">tambah</a>
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>NPM</th>
                          <th>Nama</th>
                          <th>Tempat Lahir</th>
                          <th>Tanggal Lahir</th>
                          <th>Alamat</th>
                          <th>Prodi ID</th>
                          <th>URL Foto</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item["npm"]); ?></td>
                            <td><?php echo e($item["nama"]); ?></td>
                            <td><?php echo e($item["tempat_lahir"]); ?></td>
                            <td><?php echo e($item["tanggal_lahir"]); ?></td>
                            <td><?php echo e($item["alamat"]); ?></td>
                            <td><?php echo e($item["prodi"]["nama"]); ?></td>
                            <td><?php echo e($item["url_foto"]); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Nicko(sementara)\laravelsi4b\laravelsi4b\example-app\resources\views/mahasiswa/index.blade.php ENDPATH**/ ?>