<?php $__env->startSection('title','Tambah Fakultas'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">tambah mahasiswa</h4>
                  <p class="card-description">
                    Formulir tambah mahasiswa
                  </p>
                  <form method="POST"action="<?php echo e(route('mahasiswa.store')); ?>" class="forms-sample">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                      <label for="npm">NPM</label>
                      <input type="text" class="form-control" name="npm" value="<?php echo e(old('npm')); ?>">
                    </div>
                    <div class="form-group">
                      <label for="nama">Nama</label>
                      <input type="text" class="form-control" name="nama" value="<?php echo e(old('nama')); ?>" placeholder="Nama Mahasiswa">
                      <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                      <label for="tempat_lahir">Tempat Lahir</label>
                      <input type="text" class="form-control" name="tempat_lahir" value="<?php echo e(old('tempat_lahir')); ?>">
                    </div>
                     <div class="form-group">
                      <label for="tanggal_lahir">Tanggal Lahir</label>
                      <input type="date" class="form-control" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir')); ?>">
                    </div>
                     <div class="form-group">
                      <label for="alamat">Alamat</label>
                      <input type="text" class="form-control" name="alamat" value="<?php echo e(old('alamat')); ?>">
                    </div>
                    <div class="form-group">
                      <label for="prodi_id">Prodi_Id</label>
                      <select name="prodi_id"
                      class="form-control">
                            <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item['id']); ?>">
                                    <?php echo e($item['nama']); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                     <div class="form-group">
                      <label for="url_foto">Url Foto</label>
                      <input type="text" class="form-control" name="url_foto" value="<?php echo e(old('url_foto')); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary mr-2">Simpan</button>
                    <a href="<?php echo e(url('fakultas')); ?>" class="btn btn-light">Batal</button>
                  </form>
                </div>
              </div>
            </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Nicko(sementara)\laravelsi4b\laravelsi4b\example-app\resources\views/mahasiswa/create.blade.php ENDPATH**/ ?>